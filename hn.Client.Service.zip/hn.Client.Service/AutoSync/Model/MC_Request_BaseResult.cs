﻿namespace hn.AutoSyncLib.Model
{
    public class MC_Request_BaseResult
    {
        public int Status { get; set; }
        public string Msg { get; set; }
        public string Comid { get; set; }
        public int TotalCount { get; set; }

    }
}