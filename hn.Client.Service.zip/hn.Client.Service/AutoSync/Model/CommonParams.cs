﻿namespace hn.AutoSyncLib.Model
{
    public interface CommonParams
    {
        string action { get; set; }
        string comid { get; set; }
        string khhm { get; set; }
    }
}